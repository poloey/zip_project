 <!-- BEGIN SIDEBAR -->
  <div class="page-sidebar" id="main-menu">
    <!-- BEGIN MINI-PROFILE -->
    <div class="page-sidebar-wrapper scrollbar-dynamic" id="main-menu-wrapper">
      <div class="user-info-wrapper">
        <div class="profile-wrapper"> <img src="assets/img/profiles/avatar.jpg"  alt="" data-src="assets/img/profiles/avatar.jpg" data-src-retina="assets/img/profiles/avatar2x.jpg" width="69" height="69" /> </div>
        <div class="user-info">
          <div class="greeting">Welcome</div>
          <div class="username">Admin</div>
          <div class="status">Status<a href="#">
            <div class="status-icon green"></div>
            Online</a></div>
        </div>
      </div>
      <!-- END MINI-PROFILE -->
      <!-- BEGIN SIDEBAR MENU -->
      <p class="menu-title">BROWSE <span class="pull-right"><a href="javascript:;"><i class="fa fa-refresh"></i></a></span></p>

    <ul>	
      <li class="start"> <a href="home.php"> <i class="icon-custom-home"></i> <span class="title">Dashboard</span>  </a> 
		    </li>
    
          <li><a href="change-password.php"><span class="fa fa-file-text-o"></span> Change Password</a></li>
                            <li><a href="manage-users.php"><span class="fa fa-users"></span> Normal Users</a></li>
                             <li><a href="manage-interns.php"><span class="fa fa-users"></span> Interns </a></li>
                             <li><a href="manage-employee.php"><span class="fa fa-users"></span> Employee</a></li>
                             <li><a href="manage-clients.php"><span class="fa fa-users"></span> Clients </a></li>
                                  <li><a href="client-invoice.php"><span class="fa fa-users"></span> Clients Invoices </a></li>
                          <li><a href="manage-tickets.php"><span class="fa fa-ticket"></span> Manage Ticket</a></li>
                              <li ><a href="manage-quotes.php"> <span class="fa fa-tasks"></span> Manage Quotes</a></li> 
                              <li><a href="manage-career.php"><span class="fa fa-file-text-o"></span>&nbsp;&nbsp; Manage  Career</a></li>   
                            <li><a href="user-access-log.php"><span class="fa fa-users"></span>&nbsp;&nbsp;User Access Log</a></li>
                             
							    
                          
							
                           
    </ul>